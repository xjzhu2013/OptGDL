%RUN Direct comparison of Proposed and Harandi (OMP).
% Uses one fixed, source-image-grouped ORL 80/20 split and saves no results.

function run_demo()

clc;
root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'src'), '-begin');
addpath(fullfile(root, 'comparison_harandi'), '-end');
addpath(fullfile(root, 'third_party', 'spams'), '-begin');

mexLassoPath = which('mexLasso');
mexOMPPath = which('mexOMP');
[~, ~, lassoExtension] = fileparts(mexLassoPath);
[~, ~, ompExtension] = fileparts(mexOMPPath);
if isempty(mexLassoPath) || ~strcmpi(lassoExtension, ['.' mexext]) || ...
        isempty(mexOMPPath) || ~strcmpi(ompExtension, ['.' mexext])
    error(['Compatible compiled mexLasso and mexOMP binaries were not found. Read ' ...
        'third_party/00_READ_BEFORE_USING_SPAMS.md before running the demo.']);
end

dataFile = fullfile(root, 'demo_data', 'orl_demo.mat');
if ~isfile(dataFile)
    error('Demo data file not found: %s', dataFile);
end
S = load(dataFile, 'Xtr', 'Xte', 'ytr', 'yte', 'B', 'D0', ...
    'splitId', 'selectedClasses');
basePoint = S.B;

% A short ORL demonstration: both methods perform one outer iteration.
lambda = 3e-3;
outerIterations = 1;
innerIterations = 5;
classificationSeed = 2026092502;
opts = struct('update_method', 'bb2', 'gn_damping', 1e-6, ...
    'max_ls', 20, 'armijo_beta', 0.8);

fprintf('OptGDL demo\n');
fprintf(['Dataset: ORL fixed split %d (80%% train / 20%% test), ' ...
    'classes=%d, train=%d, test=%d, atoms=%d\n'], ...
    S.splitId, numel(S.selectedClasses), size(S.Xtr,3), ...
    size(S.Xte,3), numel(S.D0));
fprintf('Parameters: outer=%d, inner=%d, lambda=%g, beta=%g\n\n', ...
    outerIterations, innerIterations, lambda, opts.armijo_beta);

% Use all CPU cores detected by MATLAB when Parallel Computing Toolbox is available.
try
    pool = gcp('nocreate');
    if isempty(pool)
        requestedWorkers = feature('numcores');
        parpool('Threads', requestedWorkers);
    end
catch poolError
    warning('OptGDL:ParallelPool', ...
        'Thread pool was not started (%s). MATLAB may run loops serially.', ...
        poolError.message);
end

XtrCell = array_to_cell(S.Xtr);
timerProposed = tic;
[~, Ytr, LogD, loss] = L_GDL_optim_with_history( ...
    XtrCell, S.D0, basePoint, lambda, outerIterations, innerIterations, opts);

XteCell = array_to_cell(S.Xte);
LogXte = cell(1, numel(XteCell));
parfor i = 1:numel(XteCell)
    LogXte{i} = grassmann_log(basePoint, XteCell{i});
end
Yte = L_GSC(LogXte, LogD, lambda);

% Reset the same classifier seed inside classify_codes for both methods.
accuracyProposed = classify_codes( ...
    Ytr, Yte, S.ytr, S.yte, classificationSeed);
timeProposed = toc(timerProposed);

fprintf('\nRunning Harandi extrinsic comparison...\n');
timerHarandi = tic;
D0Array = cat(3, S.D0{:});
harandiOptions = struct('nIter', outerIterations, 'L', 8, ...
    'coding', 'omp', 'lambda', lambda);
[DHarandi, lossHarandi] = grassmann_dictionary_learning_track( ...
    S.Xtr, size(D0Array,3), harandiOptions, D0Array);
Atr = sparse_coding_mexomp_grassmann(S.Xtr, DHarandi, harandiOptions.L);
Ate = sparse_coding_mexomp_grassmann(S.Xte, DHarandi, harandiOptions.L);
accuracyHarandi = classify_codes( ...
    Atr', Ate', S.ytr, S.yte, classificationSeed);
timeHarandi = toc(timerHarandi);

fprintf('\nDemo finished. Fair comparison on the same split and initialization:\n');
fprintf('Proposed : accuracy = %.2f%%, time = %.2f s, loss = %.4f -> %.4f\n', ...
    accuracyProposed, timeProposed, loss(1), loss(end));
fprintf('Harandi  : accuracy = %.2f%%, time = %.2f s, loss = %.4f -> %.4f\n', ...
    accuracyHarandi, timeHarandi, lossHarandi(1), lossHarandi(end));
fprintf('Harandi/Proposed time ratio: %.2fx\n', timeHarandi / timeProposed);
end

function C = array_to_cell(X)
C = cell(1, size(X,3));
for k = 1:size(X,3)
    C{k} = X(:,:,k);
end
end

function accuracy = classify_codes(Ytr, Yte, ytr, yte, classificationSeed)
% KernelScale='auto' uses random subsampling; reset the same seed so that
% both methods receive an identical, reproducible classifier configuration.
previousRngState = rng;
restoreRng = onCleanup(@() rng(previousRngState));
rng(classificationSeed, 'twister');
learner = templateSVM('KernelFunction', 'rbf', 'KernelScale', 'auto', ...
    'BoxConstraint', 10, 'Standardize', false);
model = fitcecoc(double(Ytr), ytr(:), 'Learners', learner, ...
    'Coding', 'onevsall', 'ClassNames', unique(ytr(:)));
prediction = predict(model, double(Yte));
accuracy = 100 * mean(prediction == yte(:));
clear restoreRng
end
