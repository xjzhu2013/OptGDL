# 使用 SPAMS 前请先阅读

本演示使用 SPAMS 2.6 的 `mexLasso` 和 `mexOMP` 加速稀疏编码。SPAMS 是
第三方软件，不是本文作者的原创代码；许可证见 `spams/COPYING`。

仓库内的 `mexLasso.mexw64` 与 `mexOMP.mexw64` 是 Windows x64 二进制
文件，已在本项目使用的 MATLAB R2025b 环境中通过测试。

## 是否需要重新编译

- 同为 Windows x64，只更换普通 x86-64 电脑或 CPU：通常不需要，先直接
  运行 `run_demo` 检查。
- 更换为 Linux、macOS 或 ARM/Apple Silicon：必须重新编译。
- MATLAB 报告 `Invalid MEX-file`、缺少 DLL 或入口点错误：需要重新编译。
- 只更换显卡：通常不需要；这里是 CPU MEX，不是 CUDA 程序。

完整 SPAMS 2.6 源码包位于 `spams/spams-matlab-v2.6-source.tar.gz`。
重新编译前，应为当前 MATLAB 安装官方支持的 C++ 编译器，并执行：

```matlab
mex -setup C++
```

随后解压源码包，阅读其中的 `HOW_TO_INSTALL.txt`，并运行或调整 `compile.m`。
SPAMS 2.6 较旧，在新版 MATLAB 中可能需要调整 BLAS/LAPACK 路径或 MEX
API 兼容选项。不同操作系统生成的 MEX 文件不能通过更改扩展名互相替代。
