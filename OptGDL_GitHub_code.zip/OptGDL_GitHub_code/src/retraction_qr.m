function Y = retraction_qr(Z)
    [Q, R] = qr(Z, 0);
    s=sign(diag(R));
    s(s==0)=1;
    Y=Q*diag(s);
end
