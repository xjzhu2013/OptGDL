# Harandi extrinsic comparison

This directory contains the minimal extrinsic Grassmann dictionary-learning
comparison used by `run_demo.m`. It is kept separate from the proposed method.

The implementation follows:

- M. Harandi, C. Sanderson, C. Shen, and B. C. Lovell, “Dictionary learning
  and sparse coding on Grassmann manifolds: An extrinsic solution,” ICCV 2013,
  pp. 3120–3127.
- M. Harandi, R. Hartley, C. Shen, B. Lovell, and C. Sanderson, “Extrinsic
  Methods for Coding and Dictionary Learning on Grassmann Manifolds,” IJCV,
  114:113–136, 2015. DOI: 10.1007/s11263-014-0798-6.

These files are included only to reproduce the comparison and should not be
described as original contributions of the OptGDL authors.

