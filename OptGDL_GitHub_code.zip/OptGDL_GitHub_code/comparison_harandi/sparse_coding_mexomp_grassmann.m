function alpha = sparse_coding_mexomp_grassmann(X_all, D, L)
% OMP sparse coding for the projection-matrix Grassmann model
%
% X_all : d x p x m
% D     : cell{N} of d x p, or d x p x N, or p x d x N
% L     : OMP sparsity level
%
% alpha : N x m

    if nargin < 3 || isempty(L)
        error('Need sparsity level L.');
    end

    D = normalize_dictionary_format(D, X_all);   % -> d x p x N

    [~, p, ~] = size(X_all);

    % ---- Projection kernel matrices ----
    % K_D(j,k)  = || D_j' D_k ||_F^2
    % K_XD(j,i) = || D_j' X_i ||_F^2
    K_D  = grassmann_proj_kernel(D);         % N x N
    K_XD = grassmann_proj_kernel(D, X_all)'; % N x m

    % ---- Whitening ----
    [U, S] = svd(K_D, 'econ');
    s = diag(S);
    s = max(s, 1e-10);

    A = (diag(sqrt(s)) * U') / sqrt(p);                  % N x N
    Xstar = (diag(1 ./ sqrt(s)) * U') * K_XD / sqrt(p);  % N x m

    % ---- Column normalization for OMP stability ----
    coln = sqrt(sum(A.^2, 1));
    coln(coln < 1e-12) = 1;
    A_norm = bsxfun(@rdivide, A, coln);

    if exist('mexOMP', 'file') ~= 2 && exist('mexOMP', 'file') ~= 3
        error('mexOMP not found on MATLAB path.');
    end

    param.L = double(L);
    alpha = full(mexOMP(Xstar, A_norm, param));   % N x m

    % restore coefficients to original dictionary scale
    alpha = bsxfun(@rdivide, alpha, coln(:));
end

% ============================================================
function D = normalize_dictionary_format(D, X_all)
% Convert D to d x p x N and align with X_all

    d = size(X_all, 1);
    p = size(X_all, 2);

    if iscell(D)
        D = cat(3, D{:});
    end

    if ndims(D) ~= 3
        error('Dictionary D must be cell or 3D array.');
    end

    d0 = size(D, 1);
    p0 = size(D, 2);

    if d0 == d && p0 == p
        % correct
    elseif d0 == p && p0 == d
        Dt = zeros(d, p, size(D, 3));
        for k = 1:size(D, 3)
            Dt(:, :, k) = D(:, :, k)';
        end
        D = Dt;
    else
        error('Dictionary/data dimension mismatch: X_all=[%d,%d,*], D=[%d,%d,*].', ...
              d, p, d0, p0);
    end

    % re-orthonormalize atoms
    for k = 1:size(D, 3)
        [Q, ~] = qr(D(:, :, k), 0);
        D(:, :, k) = Q;
    end
end

% ============================================================
function K = grassmann_proj_kernel(SY1, SY2)
% Projection kernel:
%   K(b,a) = || SY1(:,:,a)' * SY2(:,:,b) ||_F^2
%
% One input  -> pairwise kernel in SY1
% Two inputs -> (#SY2) x (#SY1)

    MIN_THRESH = 1e-6;

    if nargin < 2
        SY2 = SY1;
        same_flag = true;
    else
        same_flag = false;
    end

    if size(SY1, 1) ~= size(SY2, 1)
        error('Ambient dimension mismatch: SY1=[%d,%d,*], SY2=[%d,%d,*].', ...
              size(SY1,1), size(SY1,2), size(SY2,1), size(SY2,2));
    end

    p  = size(SY1, 2);
    n1 = size(SY1, 3);
    n2 = size(SY2, 3);

    K = zeros(n2, n1);

    if same_flag
        for a = 1:n1
            Y1 = SY1(:, :, a);
            for b = a:n2
                M = Y1' * SY2(:, :, b);
                v = sum(M(:).^2);
                if v < MIN_THRESH, v = 0; end
                if v > p, v = p; end
                K(b, a) = v;
                K(a, b) = v;
            end
        end
    else
        for a = 1:n1
            Y1 = SY1(:, :, a);
            for b = 1:n2
                M = Y1' * SY2(:, :, b);
                v = sum(M(:).^2);
                if v < MIN_THRESH, v = 0; end
                if v > p, v = p; end
                K(b, a) = v;
            end
        end
    end
end