# OptGDL MATLAB code

This repository provides the MATLAB implementation for "Optimization for
Grassmann Dictionary Learning with Stiefel Representatives." It contains:

- the proposed method's core MATLAB functions in `src/`;
- the Harandi extrinsic comparison in `comparison_harandi/`;
- one fixed ORL demonstration split in `demo_data/`;
- the SPAMS `mexLasso` and `mexOMP` acceleration used by the two methods;
- one entry point: `run_demo.m`.

## Run

Open MATLAB in this directory and execute:

```matlab
run_demo
```

The demo compares the proposed method with Harandi's extrinsic method on a
fixed ORL split. Both methods use the same split, initial dictionary,
classification settings, and one outer dictionary-learning iteration.

MATLAB R2025b and Statistics and Machine Learning Toolbox are required for the
included classification step. Parallel Computing Toolbox is recommended.

## SPAMS

Read `third_party/00_READ_BEFORE_USING_SPAMS.md`. The included
`mexLasso.mexw64` and `mexOMP.mexw64` are Windows x64 binaries tested with
MATLAB R2025b. Source package and license are included for rebuilding on
another platform.
